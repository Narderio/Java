public class Quadrato extends Rettangolo {
    public Quadrato(int lato) {
        super(lato, lato);
    }

    @Override
    public void calcolaArea() {
        super.calcolaArea();
    }

    public void calcolaPerimetro() {
        super.calcolaPerimetro();
    }

    @Override
    public void disegna() {
        super.disegna();
    }


}
