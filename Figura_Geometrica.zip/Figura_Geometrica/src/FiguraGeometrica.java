public abstract class FiguraGeometrica {

    public abstract void calcolaArea();

    public abstract void calcolaPerimetro();
}
